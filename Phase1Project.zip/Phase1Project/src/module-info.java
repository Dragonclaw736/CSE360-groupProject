module Phase1Project {
	requires javafx.controls;
	
	opens cse360Project to javafx.graphics, javafx.fxml;
}
