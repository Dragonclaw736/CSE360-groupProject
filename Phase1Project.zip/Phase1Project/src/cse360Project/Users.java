package cse360Project;


public class Users {
	private String _email;
	private String _username;
	private _TYPE_ _password;
}

