module CSE360Project {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
